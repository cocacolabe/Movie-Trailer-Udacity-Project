
# Movie Trailer


#### Description

Movie Trailer is a single web page that allows user to watching movie trailer.
 
#### How to open the file?

##### Open from folder:
 1. Quickly Double click the compressed file .
 2. Find the **movie_trailer.html** file and right click it.
 3. Select the Browser you prefer
 4. Enjoy!

##### Open from terminal:
1. Go directly to the location where you store the file
2. Run the command line below
```
$ python entertainment_center.py
```
